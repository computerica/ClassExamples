package com.company;

public class Main
{
    private static int stepCounter = 0;
    public static int getStepCounter() {return stepCounter;}
    public static void setStepCounter(int thisStepCounter) {stepCounter = thisStepCounter;}

    public static void main(String[] args)
    {
        move(4, "A", "B", "C", -1);
    }

    public static void move(int disc, String origin, String destination, String spare, int numberOfSpaces)
    {
        numberOfSpaces++;

        // STOP CONDITION
        if (disc == 0)
        {
            printOutput(disc, origin, destination, numberOfSpaces);
        }

        // RECURSION
        else
        {
            move(disc - 1, origin, spare, destination, numberOfSpaces);
            printOutput(disc, origin, destination, numberOfSpaces);
            move(disc - 1, spare, destination, origin, numberOfSpaces);
        }
    }

    public static void printOutput(int disc, String origin, String destination, int numberOfSpaces)
    {
        setStepCounter(stepCounter + 1);
        System.out.print(printSpaces(numberOfSpaces));
        System.out.println("Step " + stepCounter + ": Move disc " + disc + " from " + origin + " to " + destination + ".");
    }

    //  INCOMPLETE
    public static String printSpaces(int numberOfSpaces)
    {
        String output = "";

        for (int i = 0; i < numberOfSpaces; i++)
        {
            output += "|______";
        }

        return output;
    }
}
